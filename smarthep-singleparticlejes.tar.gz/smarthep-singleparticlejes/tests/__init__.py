"""
Basic test configuration for SmartHEP SingleParticleJES package.

This file ensures pytest can find the package modules.
"""

import pytest
