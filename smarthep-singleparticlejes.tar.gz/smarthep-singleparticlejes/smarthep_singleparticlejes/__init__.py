"""
SmartHEP SingleParticleJES - High Energy Physics Analysis Package

A package for analyzing single particle jet energy scale calibration in ATLAS.
"""

__version__ = "0.1.0"
